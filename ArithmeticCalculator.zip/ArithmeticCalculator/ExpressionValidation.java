package calculator_Application;

public class ExpressionValidation {
	public static boolean validate(String expression) {
		char[] exp = expression.toCharArray();

		for (int i = 0; i < exp.length; i++) {
			if ((exp[i] >= 'a' && exp[i] <= 'p') || (exp[i] >= 'u' && exp[i] <= 'z') || (exp[i] >= 'A' && exp[i] <= 'P')
					|| (exp[i] >= 'U' && exp[i] <= 'Z') || (exp[i] >= 58 && exp[i] <= 63) || (exp[i]) == '!'
					|| (exp[i]) == '"' || (exp[i]) == '#' || (exp[i]) == '&' || (exp[i]) == '@' || (exp[i]) == '~'
					|| (exp[i]) == '`' || (exp[i]) == '|' || (exp[i]) == '$'|| (exp[i]) == '_') {
				return false;
			}
		}

		return true;
	}
}
