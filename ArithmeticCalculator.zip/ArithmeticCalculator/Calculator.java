package calculator_Application;

import java.util.Scanner;

public class Calculator extends PerformOperation {

	public static void main(String[] args) {
		Calculator cal = new Calculator();
		cal.getString();
	}

	private void getString() {
		try (Scanner sc = new Scanner(System.in)) {
			String choice;
			do {
			System.out.println("\nEnter expression : ");
			String expression = sc.next();
			if (ExpressionValidation.validate(expression)) {
//				do_Operation(expression);
				PerformEvaluation per = new PerformEvaluation(expression);
				System.out.println(expression+" = "+per.Evaluate());
			}
			else 
				System.out.println("Expression contain alphabets or special characters... invalid expression to compute !");
			System.out.println("\nEnter choice \n0-- exit\nany alpha numeric value to-- continue  : ");
			choice = sc.next();
			}while(!choice.equals("0"));
			System.out.println("calculator closed");
		}
	}
}
